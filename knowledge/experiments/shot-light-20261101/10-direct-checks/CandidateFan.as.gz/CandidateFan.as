package {import flash.display.*;import flash.geom.*;public class CandidateFan {public const cell:int=12;public var loc:*;public var reuses:int=0;
public function makeLight(light:Object,previous:Object=null):BitmapData {
            var radius:Number=Number(light.radius);
            var side:int=Math.ceil(radius*2/cell)+1;
            var root:Sprite=new Sprite(),glow:Sprite=root,mask:Sprite=root;
            var matrix:Matrix=new Matrix(); matrix.createGradientBox(radius*2/cell,radius*2/cell);
            glow.graphics.beginGradientFill(GradientType.RADIAL,[0xFFFFFF,0xFFFFFF,0],[1,1,1],[0,45,255],matrix);
            
            var cone:Number=Number(light.cone),center:Number=Number(light.angle);
            var full:Boolean=cone>=Math.PI*2-0.01;
            var start:Number=full?0:center-cone/2;
            var count:int=light.transient?64:Math.max(24,Math.ceil(cone/(Math.PI/90)));
            if(!full) mask.graphics.moveTo(radius/cell,radius/cell);
            for(var i:int=0;i<=count;i++) {
                var angle:Number=start+cone*i/count;
                var distance:Number=traceRay(light.x,light.y,Math.cos(angle),Math.sin(angle),radius);
                var px:Number=(radius+Math.cos(angle)*distance)/cell;
                var py:Number=(radius+Math.sin(angle)*distance)/cell;
                if(i==0 && full) mask.graphics.moveTo(px,py);else mask.graphics.lineTo(px,py);
            }
            if(!full) mask.graphics.lineTo(radius/cell,radius/cell);
            mask.graphics.endFill();
            var result:BitmapData=new BitmapData(side,side,false,0);
            result.draw(root);return result;
        }
public function traceRay(sx:Number,sy:Number,dx:Number,dy:Number,radius:Number):Number {
            var cx:int=Math.floor(sx/40),cy:int=Math.floor(sy/40);
            var stepX:int=dx<0?-1:1,stepY:int=dy<0?-1:1;
            var nextX:Number=Math.abs(dx)<0.00001?1e20:((cx+(stepX>0?1:0))*40-sx)/dx;
            var nextY:Number=Math.abs(dy)<0.00001?1e20:((cy+(stepY>0?1:0))*40-sy)/dy;
            var deltaX:Number=Math.abs(dx)<0.00001?1e20:Math.abs(40/dx);
            var deltaY:Number=Math.abs(dy)<0.00001?1e20:Math.abs(40/dy);
            var distance:Number=0,opacity:Number=0;
            while(distance<radius) {
                if(nextX<nextY) {distance=nextX;nextX+=deltaX;cx+=stepX;}
                else {distance=nextY;nextY+=deltaY;cy+=stepY;}
                if(distance>=radius) break;
                if(cx<0||cy<0||cx>=loc.spaceX||cy>=loc.spaceY) return Math.max(0,distance);
                opacity+=Math.max(0,Number(loc.space[cx][cy].opac));
                if(opacity>=0.99) return Math.max(0,distance-1);
            }
            return radius;
        }
}}